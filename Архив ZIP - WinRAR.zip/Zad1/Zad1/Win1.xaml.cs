﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Zad1
{
    /// <summary>
    /// Логика взаимодействия для Win1.xaml
    /// </summary>
    public partial class Win1 : Window
    {
        public Win1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (Login.Text == "Администратор" && Password.Password == "12345")
            {
                Win2 win = new Win2();
                win.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }
    }
}
